 _______________________________________________________________________________________
< 	Proyecto realizado en el tercer bimestre de la carrera Certified tech Developer
en la materia Backend1 a cargo del prof Peter Bauman. Para ejecutarlo debes de abrir el
proyecto en el IDE ejecutar con maven clean y package y ya esta listo para visualizar en
el localhost/8080>
 ---------------------------------------------------------------------------------------
 	       \   ^__^
 	        \  (oo)\_______
  	          (__)\       )\/\
  	              ||----w |
  	              ||     ||
