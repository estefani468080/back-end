package com.miintegrador.miintegrador.services.segurity;

public enum AppUsuarioRole {
    USER,ADMIN
}
