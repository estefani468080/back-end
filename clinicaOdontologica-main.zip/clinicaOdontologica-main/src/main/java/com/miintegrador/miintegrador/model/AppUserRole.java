package com.miintegrador.miintegrador.model;

public enum AppUserRole {
    USER,ADMIN
}
